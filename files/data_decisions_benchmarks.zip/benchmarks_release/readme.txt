Each dataset is stored in a .pickle file which contains a single tuple (ground truth, features). 

Budget allocation: 
The ground truth is a list of 1000 (100 x 500) numpy matricies. Each list entry is a problem instance, and the ij entry of each matrix is the probability that channel i will reach consumer j. The features is a list of 1000 (100 x 500) numpy matrix, where row i of each feature matrix is the feature vector corresponding to channel i in that instance. 

Diverse recommendation:
The ground truth is a list of 101 (100 x 500) numpy matricies. Each list entry is a problem instance, and the ij entry of each matrix is a binary indicator for whether movie i contains actor j. The features is a list of 101 (100 x 2113) numpy matricies. Row i of each feature matrix is the ratings assigned by each user to movie i of the corresponding instance (with a 0 for missing entries). 

Matching: 
To save on space, a python file is included to generate the dataset used in the experiments from the cora dataset. Run make_cora_dataset.py to generate a .pickle file with (ground truth, features). The ground truth is a (27 x 2500) numpy matrix. Each row is an instance. This row contains the flattened adjacency matrix for the 50 nodes in the instance, which is a binary indicator for whether each of the 2500 possible edges is present. The features contain a (27 x 2500 x 2866) numpy matrix where the ij entry is a feature vector for edge j in instance i. This is the concatenation of the bag of words features for the nodes that the potential edge connects. 