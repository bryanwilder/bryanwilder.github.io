require("EpiEstim")
library(glue)

test_frequency = 1 
design = "uniform_piecewise"
options(scipen = 999)
for (test_type in c("pcr","sero")){
  for (frac_tested in c(0.01, 0.02, 0.05, 0.1, 0.2)){
    
    
    #c(0.005, 0.01, 0.02, 0.05)
    #c(0.005, 0.01, 0.02, 0.05)) c(0.0005, 0.001, 0.002, 0.005)
    for (idx in seq(0, 99)){
      
      path = glue("postests_{design}_{test_type}_{test_frequency}_{frac_tested}_{idx}.csv")
      
      postests = read.csv(path, header=FALSE)
      if (sum(postests) <= 3){
        next
      }
      si_distr = c(0, 0, 0, 1, 1, 1, 1, 1, 1, 1)/7
      
      result_cori = estimate_R(postests, method = "non_parametric_si", config=list(si_distr=si_distr, t_start = seq(2, 86), t_end = seq(16, 100)))
      result_wt = wallinga_teunis_custom(postests, method = "non_parametric_si", config=list(si_distr=si_distr, t_start = seq(2, 86), t_end = seq(16, 100), n_sim=1000))
      
      path = glue("results_wt_{design}_{test_type}_{test_frequency}_{frac_tested}_{idx}.results")
      write.csv(result_wt$R, path)
      path = glue("results_cori_{design}_{test_type}_{test_frequency}_{frac_tested}_{idx}.results")
      write.csv(result_cori$R, path)
    }
  }
}