import numpy as np

seroconversion_pdf =  np.loadtxt('sero_conversion_pdf.txt')
pcr_conversion_pdf = np.loadtxt('pcr_conversion_pdf.txt')
pcr_reversion_pdf = np.loadtxt('pcr_reversion_pdf.txt')
infectiousness_per_day = np.loadtxt('infectiousness_per_day.txt')
anamnestic_pdf = np.loadtxt('anamnestic_pdf.txt')
delay_distr = 1./6 * np.ones(6)

for test_type in ['pcr', 'sero']:
    for design in ['imports_piecewise', 'imports', 'xsection', 'xsection_piecewise', 'uniform', 'uniform_piecewise']:
        if 'imports' in design:
            freqvals = [7, 14, 31]
        else:
            freqvals = [1]
        for test_frequency in freqvals:
        
            if test_type == 'pcr':
                delay_vals = []
                for _ in range(10000):
                    convert_time = np.random.choice(pcr_conversion_pdf.shape[0], p = pcr_conversion_pdf)
                    if 'uniform' in design:
                        delay_vals.append(convert_time + np.random.choice(np.arange(len(delay_distr)), p=delay_distr))
                    else:
                        revert_time = np.random.choice(pcr_reversion_pdf[convert_time].shape[0], p = pcr_reversion_pdf[convert_time])
                        next_test = np.random.randint(0, test_frequency)
                        while next_test < convert_time:
                            next_test += test_frequency
                        if next_test < revert_time:
                            delay_vals.append(next_test)
            else:
                delay_vals = []
                for _ in range(10000):
                    convert_time = np.random.choice(seroconversion_pdf.shape[0], p = seroconversion_pdf)
                    if 'uniform' in design:
                        delay_vals.append(convert_time + np.random.choice(np.arange(len(delay_distr)), p=delay_distr))
                    else:
                        next_test = np.random.randint(0, test_frequency)
                        while next_test < convert_time:
                            next_test += test_frequency
                        delay_vals.append(next_test)
                
            mean_delay = int(np.round(np.mean(delay_vals)))
            
            np.savetxt('delay_samples_{}_{}_{}.csv'.format(design, test_type, test_frequency), np.round(delay_vals), delimiter=',')
