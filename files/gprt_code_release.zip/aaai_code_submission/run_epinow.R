require("EpiNow2")
library(glue)

args = commandArgs(trailingOnly=TRUE)

design = args[1]
test_type = args[2]
test_frequency = args[3]
frac_tested = args[4]
idx = args[5]
expdir = args[6]
print(args)
options(scipen = 999) 

si_samples = sample.int(7, 10000, replace = TRUE) + 3
si_distr = list(mean=mean(si_samples), sd = sd(si_samples), mean_sd=0.001, sd_sd = 0.001, max=10)

path = glue("delay_samples_{design}_{test_type}_{test_frequency}.csv")
delay_samples = read.csv(path, header=FALSE)
delay_distr = EpiNow2::bootstrapped_dist_fit(delay_samples$V1[1:1000])
  

path = glue("postests_{design}_{test_type}_{test_frequency}_{frac_tested}_{idx}.csv")
postests = read.csv(path, header=FALSE)

cases = list(confirm = postests$V1, date=seq(ISOdate(2020,1,1), by = "day", length.out = length(postests$V1)))
cases = data.frame(cases)
def <- estimate_infections(cases, family = "poisson",
                           generation_time = si_distr,
                           delays = list(delay_distr),
                           samples = 1000, warmup = 200, cores = 4,
                           chains = 4, estimate_rt = TRUE, verbose = TRUE, return_fit = TRUE, horizon=0)

path = glue("{expdir}/results_epinow_{design}_{test_type}_{test_frequency}_{frac_tested}_{idx}.results")
write.csv(def$samples, path)
