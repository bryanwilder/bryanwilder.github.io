import numpy as np
import torch
import math
from functions import categorical_sample, resevoir_sample
from numba import jit
from math import lgamma
from functools import partial
import scipy as sp
import scipy.stats
#import multiprocessing
import threading
import pickle
import argparse
import matplotlib.pyplot as plt
from testing_variational import simulate_wrapper, sample_trajectory, sample_trajectory_crosssection, sample_trajectory_uniform

test_frequency = 1
design = 'uniform'
setting = 'outbreak'
delay_distr = 1./6 * np.ones(6)

np.random.seed(0)
if 'xsection' in design:
    all_fracs =  [0.0005, 0.001, 0.002, 0.005]
elif 'uniform' in design:
    all_fracs = [0.01, 0.02, 0.05, 0.1, 0.2]
else:
    all_fracs = [0.005, 0.01, 0.02, 0.05]
    
for frac_tested in all_fracs:
    for testtype in ['pcr', 'sero']:
        for idx in range(100):
            seroconversion_pdf =  np.loadtxt('sero_conversion_pdf.txt')
            pcr_conversion_pdf = np.loadtxt('pcr_conversion_pdf.txt')
            pcr_reversion_pdf = np.loadtxt('pcr_reversion_pdf.txt')
            infectiousness_per_day = np.loadtxt('infectiousness_per_day.txt')
            anamnestic_pdf = np.loadtxt('anamnestic_pdf.txt')
            import_mean = np.random.randint(5, 16)
            prev_infected_frac = 0.0
            num_init_infected = 5
            n = int(1e5)
            T = 100
            r_time_all = np.zeros((1, T), dtype=np.float32)
#
            if setting == 'outbreak':
                r_low = np.random.uniform(0.2, 0.8)
                r_high = np.random.uniform(1.2, 2)
                transition = np.random.randint(20, 61)
                transition_days = np.random.randint(1, 20)
                
                r_time_all[0, :transition] = r_low
                r_time_all[0, transition+transition_days:] = r_high
                r_time_all[0, transition:transition+transition_days] = r_low + (r_high - r_low)*np.arange(transition_days)/transition_days

            else:
                transition_points = [15, 40, 60, 85]
                r_vals = 2*np.random.rand(len(transition_points))
                r_vals[0] = 0.8
                r_time_all[0, :transition_points[0]] = r_vals[0]
                r_time_all[0, transition_points[-1]:] = r_vals[-1]
                for i in range(1, len(transition_points)):
                    r_time_all[0, transition_points[i-1]:transition_points[i]] = r_vals[i-1] + (r_vals[i] - r_vals[i-1])*np.arange(transition_points[i] - transition_points[i-1])/(transition_points[i] - transition_points[i-1])
            
            
            
            from sklearn.gaussian_process.kernels import Matern
            kernel = Matern(length_scale=10.0, nu=1.5)
            prior_cov = kernel(np.arange(T).reshape((T, 1))) 
            
            r_time_all += 0.05*np.random.multivariate_normal(np.zeros(100), prior_cov)
#            plt.plot(r_time_all.flatten())
            
            num_tested_per_day = int(n*frac_tested/test_frequency)
            num_samples = 1
            burn_in = 40
            
            
            simulate_function = partial(simulate_wrapper, n=n, T=T, prev_infected_frac=prev_infected_frac, pcr_conversion_pdf=pcr_conversion_pdf, pcr_reversion_pdf=pcr_reversion_pdf, seroconversion_pdf=seroconversion_pdf, anamnestic_pdf=anamnestic_pdf, num_init_infected=num_init_infected, infectiousness_per_day=infectiousness_per_day, burn_in=burn_in)
            
            #    raise Exception()
            infectious_all_days, new_infected, reexposed, fraction_susceptible_day, fraction_suceptible_reexposure_day, seroconversion_per_day, pcr_conversion_per_day = simulate_function(1, r_time_all, np.array([import_mean]), 1)
            
            if testtype == 'sero':
                conversions = seroconversion_per_day[0]
            else:
                conversions = pcr_conversion_per_day[0]
                
            if 'xsection' in design:
                postests_per_day_full = sample_trajectory_crosssection(conversions, test_frequency, num_tested_per_day, n, T)
            elif 'uniform' in design:
                postests_per_day_full = sample_trajectory_uniform(conversions, frac_tested, delay_distr, n, T)
            else:
                postests_per_day_full = sample_trajectory(conversions, test_frequency, num_tested_per_day, n, T)
            
#            raise Exception()
            if setting == 'outbreak':
                pickle.dump((postests_per_day_full, r_time_all, testtype, test_frequency, frac_tested, r_low, r_high, transition, transition_days, import_mean, delay_distr), open('inference_instance_{}_{}_{}_{}_{}.pkl'.format(design, testtype, test_frequency, frac_tested, idx), 'wb'))
            else:
                pickle.dump((postests_per_day_full, r_time_all, testtype, test_frequency, frac_tested, transition_points, r_vals, import_mean, delay_distr), open('inference_instance_{}_{}_{}_{}_{}.pkl'.format(design, testtype, test_frequency, frac_tested, idx), 'wb'))

