import numpy as np
import torch
import math
from functions import categorical_sample, resevoir_sample
from numba import jit
from math import lgamma
from functools import partial
import scipy as sp
import scipy.stats
import threading
import pickle
import argparse
import matplotlib.pyplot as plt

@jit(nopython=True, nogil=True)
def simulate(start_sim, end_sim, infectious_all_days, new_infected, reexposed, fraction_susceptible_day, fraction_suceptible_reexposure_day, seroconversion_per_day, pcr_conversion_per_day, r_time_all, n, T, prev_infected_frac, pcr_conversion_pdf, pcr_reversion_pdf, seroconversion_pdf, anamnestic_pdf, num_init_infected, import_mean_all, infectiousness_per_day, burn_in):

    for sim in range(start_sim, end_sim):
        np.random.seed(sim)
        r_time = r_time_all[sim]
        r_time_expanded = np.zeros(T, dtype=np.float32)
        r_time_expanded[:burn_in] = r_time[0]
        r_time_expanded[burn_in:] = r_time
        r_time = r_time_expanded
        
        import_mean = import_mean_all[sim]
            
        num_infectious_day = np.zeros(14)
        num_infectious_day[0] = num_init_infected
        total_infected = num_init_infected
        
        
        n_prev_infected = int(n * prev_infected_frac)
        total_reexposed = 0
        
        for t in range(T):
            num_infectious = np.dot(num_infectious_day, infectiousness_per_day)
            expected_infections = r_time[t]/infectiousness_per_day.sum() * num_infectious + import_mean
            frac_susceptible_t = (n - total_infected - n_prev_infected)/n
            frac_susceptible_reexposure_t = (n_prev_infected - total_reexposed)/n
            new_infections_t = np.random.poisson(frac_susceptible_t * expected_infections)
            new_reexposures_t = np.random.poisson(frac_susceptible_reexposure_t * expected_infections)
            if new_infections_t >  n - total_infected - n_prev_infected:
                new_infections_t = n - total_infected - n_prev_infected
            if new_reexposures_t > n_prev_infected - total_reexposed:
                new_reexposures_t = n_prev_infected - total_reexposed
            infectious_all_days[sim, t] = num_infectious
            new_infected[sim, t] = new_infections_t
            reexposed[sim, t] = new_reexposures_t
            fraction_susceptible_day[sim, t] = frac_susceptible_t
            fraction_suceptible_reexposure_day[sim, t] = frac_susceptible_reexposure_t
            
            total_infected += new_infections_t
            total_reexposed += new_reexposures_t
            
            num_infectious_day[0] += new_infections_t
            num_infectious_day[1:] = num_infectious_day[:-1]
            num_infectious_day[0] = 0
            
            num_seroconversion_t = np.random.multinomial(new_infections_t, seroconversion_pdf)
            for convert_day in range(num_seroconversion_t.shape[0]):
                if t + convert_day >= T:
                    break
                seroconversion_per_day[sim, convert_day+t, T] += num_seroconversion_t[convert_day]
                
            num_seroconversion_reexposure_t = np.random.multinomial(new_reexposures_t, anamnestic_pdf)
            for convert_day in range(num_seroconversion_reexposure_t.shape[0]):
                if t + convert_day >= T:
                    break
                seroconversion_per_day[sim, convert_day+t, T] += num_seroconversion_t[convert_day]
            
            num_pcrconversion_t = np.random.multinomial(new_infections_t, pcr_conversion_pdf)
            for convert_day in range(num_pcrconversion_t.shape[0]):
                if t + convert_day >= T:
                    break
                num_pcrreversion = np.random.multinomial(num_pcrconversion_t[convert_day], pcr_reversion_pdf[convert_day])
                for revert_day in range(num_pcrreversion.shape[0]):
                    revert_time = revert_day+t
                    if revert_time > T:
                        revert_time = T
                    pcr_conversion_per_day[sim, convert_day+t, revert_time] += num_pcrreversion[revert_day]
    
    
def simulate_wrapper(num_sims, r_time_all, import_mean, num_threads, n, T, prev_infected_frac, pcr_conversion_pdf, pcr_reversion_pdf, seroconversion_pdf, anamnestic_pdf, num_init_infected, infectiousness_per_day, burn_in):
    T = T + burn_in
    new_infected = np.zeros((num_sims, T), dtype=np.float32)
    infectious_all_days = np.zeros((num_sims, T), dtype=np.float32)
    fraction_susceptible_day = np.zeros((num_sims, T), dtype=np.float32)
    fraction_suceptible_reexposure_day = np.zeros((num_sims, T), dtype=np.float32)
    reexposed = np.zeros((num_sims, T), dtype=np.float32)
    
    seroconversion_per_day = np.zeros((num_sims, T, T+1), dtype=np.float32)
    pcr_conversion_per_day = np.zeros((num_sims, T, T+1), dtype=np.float32)
    
    
    blocks_frac = np.linspace(0, num_sims, num_threads+1)
    blocks = np.zeros(num_threads+1, dtype=np.int32)
    for i in range(blocks_frac.shape[0]):
        blocks[i] = np.round(blocks_frac[i])
    curr_threads = []
    for i in range(num_threads):
        args = (blocks[i], blocks[i+1], infectious_all_days, new_infected, reexposed, fraction_susceptible_day, fraction_suceptible_reexposure_day, seroconversion_per_day, pcr_conversion_per_day, r_time_all, n, T, prev_infected_frac, pcr_conversion_pdf, pcr_reversion_pdf, seroconversion_pdf, anamnestic_pdf, num_init_infected, import_mean, infectiousness_per_day, burn_in)
        thread = threading.Thread(target=simulate, args=args)
        thread.start()
        curr_threads.append(thread)
#            
    for thread in curr_threads:
        thread.join()

    return infectious_all_days[:, burn_in:], new_infected[:, burn_in:], reexposed[:, burn_in:], fraction_susceptible_day[:, burn_in:], fraction_suceptible_reexposure_day[:, burn_in:], seroconversion_per_day[:, burn_in:, burn_in:], pcr_conversion_per_day[:, burn_in:, burn_in:]
        
        
@jit(nopython=True)
def likelihood(start_idx, end_idx, all_log_liks, conversions_per_day, postests_per_day, test_frequency, num_tested_per_day, n, num_samples):
    for idx in range(start_idx, end_idx):
        np.random.seed(idx)
        conversions_per_day_2 = conversions_per_day[idx]
        remaining_conversions = conversions_per_day_2.copy()
        unconverted_cohort_members = num_tested_per_day * np.ones(test_frequency, dtype=np.int32)
        for t in range(conversions_per_day.shape[1]):
            min_t = t - test_frequency
            if min_t < 0:
                min_t = 0
            conversions_slice = remaining_conversions[min_t:t+1, t+1:]
            possible_conversions = conversions_slice.sum()
            num_pos = postests_per_day[t]
            if possible_conversions < num_pos:
                all_log_liks[idx, t] = -10000
                continue
            if possible_conversions == 0 and num_pos == 0:
                all_log_liks[idx, t] =  0
                continue
            p_positive = possible_conversions/(n - postests_per_day[:t].sum())
            num_draws = unconverted_cohort_members[t%test_frequency]
            all_log_liks[idx, t] = lgamma(num_draws+1) - lgamma(num_pos+1) - lgamma(num_draws - num_pos + 1) + num_pos*np.log(p_positive) + (num_draws - num_pos)*np.log(1-p_positive)
            unconverted_cohort_members[t%test_frequency] -= num_pos
            for n_assigned in range(num_pos):
                index_tested = categorical_sample(conversions_slice.flatten()/(possible_conversions - n_assigned))
                day_converted = index_tested // conversions_slice.shape[1]
                day_reverted = index_tested % conversions_slice.shape[1]
                conversions_slice[day_converted, day_reverted] -= 1

@jit(nopython=True)
def likelihood_crosssection(start_idx, end_idx, all_log_liks, conversions_per_day, postests_per_day, test_frequency, num_tested_per_day, n, num_samples):
    for idx in range(start_idx, end_idx):
        all_conv = conversions_per_day[idx].sum(axis=1)
        all_rev = conversions_per_day[idx].sum(axis=0)
        curr_pos = 0
        for t in range(conversions_per_day.shape[1]):
            curr_pos += all_conv[t]
            curr_pos -= all_rev[t]
            num_pos = postests_per_day[t]
            if curr_pos < num_pos:
                all_log_liks[idx, t] = -10000
                continue
            if curr_pos == 0 and num_pos == 0:
                all_log_liks[idx, t] =  0
                continue
            p_positive = curr_pos/n
            num_draws = num_tested_per_day
            all_log_liks[idx, t] = lgamma(num_draws+1) - lgamma(num_pos+1) - lgamma(num_draws - num_pos + 1) + num_pos*np.log(p_positive) + (num_draws - num_pos)*np.log(1-p_positive)

@jit(nopython=True)
def likelihood_uniform(start_idx, end_idx, all_log_liks, conversions_per_day, postests_per_day, p_tested, delay_distr, n, num_samples):
    for idx in range(start_idx, end_idx):
        for _ in range(1):
            all_conv = conversions_per_day[idx].sum(axis=1).astype(np.int32)
            curr_scheduled = np.zeros(conversions_per_day.shape[1], dtype=np.int32)
            for t in range(conversions_per_day.shape[1]):
                curr_scheduled[t:t+delay_distr.shape[0]] += np.random.multinomial(all_conv[t], delay_distr)[:conversions_per_day.shape[1]-t+1]
                curr_pos = curr_scheduled[t]
                num_pos = postests_per_day[t]
                if curr_pos < num_pos:
                    all_log_liks[idx, t] += -10000
                    continue
                if curr_pos == 0 and num_pos == 0:
                    all_log_liks[idx, t] +=  0
                    continue
                p_positive = p_tested
                num_draws = curr_pos
                all_log_liks[idx, t] += lgamma(num_draws+1) - lgamma(num_pos+1) - lgamma(num_draws - num_pos + 1) + num_pos*np.log(p_positive) + (num_draws - num_pos)*np.log(1-p_positive)
        all_log_liks[idx] /= 1

def sample_trajectory(conversions_per_day, test_frequency, num_tested_per_day, n, T):
    conversions_per_day = conversions_per_day.copy()
    t_conversions = np.zeros(num_tested_per_day*test_frequency)
    t_reversions = np.zeros(num_tested_per_day*test_frequency)
    for i in range(t_conversions.shape[0]):
        if np.random.rand() < conversions_per_day.sum()/(n - i):
            index_tested = categorical_sample(conversions_per_day.flatten()/conversions_per_day.sum())
            day_converted = index_tested // conversions_per_day.shape[1]
            day_reverted = index_tested % conversions_per_day.shape[1]
            conversions_per_day[day_converted, day_reverted] -= 1
        else:
            day_converted = -1
            day_reverted = -1
        t_conversions[i] = day_converted
        t_reversions[i] = day_reverted
    postests_per_day = np.zeros(T, dtype=np.int32)
    t_conversions = t_conversions.reshape((test_frequency, num_tested_per_day))
    t_reversions = t_reversions.reshape((test_frequency, num_tested_per_day))
    for t in range(T):
        min_t = t - test_frequency
        if min_t < 0:
            min_t = 0
        postests_per_day[t] = ((t_conversions[t%test_frequency] > min_t)*(t_conversions[t%test_frequency] <= t)*(t_reversions[t%test_frequency] > t)).sum()
    return postests_per_day

def sample_trajectory_crosssection(conversions_per_day, test_frequency, num_tested_per_day, n, T):
    all_conv = conversions_per_day.sum(axis=1)
    all_rev = conversions_per_day.sum(axis=0)
    curr_pos = 0
    postests_per_day = np.zeros(T, dtype=np.int32)
    for t in range(T):
        curr_pos += all_conv[t]
        curr_pos -= all_rev[t]
        postests_per_day[t] = np.random.binomial(num_tested_per_day, curr_pos/n)
    return postests_per_day


def sample_trajectory_uniform(conversions_per_day, p_tested, delay_distr, n, T):
    all_conv = conversions_per_day.sum(axis=1).astype(np.int32)
    curr_pos = 0
    postests_per_day = np.zeros(T, dtype=np.int32)
    curr_scheduled = np.zeros(conversions_per_day.shape[1], dtype=np.int32)
    for t in range(T):
        curr_scheduled[t:t+delay_distr.shape[0]] += np.random.multinomial(all_conv[t], delay_distr)[:T-t+1]
        postests_per_day[t] = np.random.binomial(curr_scheduled[t], p_tested)
    return postests_per_day


def split_results(results):
    num_things = len(results[0])
    return (torch.tensor([x[i] for x in results]).float() for i in range(num_things))

def elbo(mu, L, batch_size, num_threads, simulate_function, likelihood_function, prior_density_function, r_max, testtype, import_mean_mean, import_mean_var):
    #reparameterized sampling from multivariance normal defined by mean mu and covariance LL^T
    itensity = mu.expand(batch_size, mu.shape[1]) + (L.expand(batch_size, *L.shape) @ torch.randn(batch_size, L.shape[1], 1)).squeeze(2)
    r = torch.relu(itensity) 
    imports_mean = torch.relu(import_mean_mean + torch.randn(batch_size)*import_mean_var)
    infectious_day, new_infected, reexposed, fraction_susceptible_day, fraction_suceptible_reexposure_day, seroconversion_per_day, pcr_conversion_per_day = simulate_function(batch_size, r.detach().numpy(), imports_mean.detach().numpy(), num_threads)
    all_log_liks = np.zeros((batch_size, seroconversion_per_day.shape[1]), dtype=np.float32)
    blocks_frac = np.linspace(0, batch_size, num_threads+1)
    blocks = np.zeros(num_threads+1, dtype=np.int32)
    for i in range(blocks_frac.shape[0]):
        blocks[i] = np.round(blocks_frac[i])
    curr_threads = []
    if testtype == 'sero':
        conversions = seroconversion_per_day
    else:
        conversions = pcr_conversion_per_day

    for i in range(num_threads):
        args = (blocks[i], blocks[i+1], all_log_liks, conversions)
        thread = threading.Thread(target=likelihood_function, args=args)
        thread.start()
        curr_threads.append(thread)
#            
    for thread in curr_threads:
        thread.join()

    log_lik = torch.tensor(all_log_liks.sum(axis=1))
    r_scaling = 7
    
    infectious_day = torch.tensor(infectious_day).float()
    fraction_susceptible_day = torch.tensor(fraction_susceptible_day).float()
    new_infected = torch.tensor(new_infected).float()
    
    mean = ((r/r_scaling)*infectious_day + imports_mean.unsqueeze(1).expand(imports_mean.shape[0], r.shape[1])) * fraction_susceptible_day
    
    log_prob_infections = (new_infected * torch.log(mean) - mean - torch.lgamma(new_infected + 1)).sum(dim = 1)
    
    log_prior = prior_density_function(itensity)
    entropy =  0.5 * torch.logdet(2*math.pi*math.e * (L @ L.T) + 0.001*torch.eye(L.shape[0])) 
    entropy_plus_prior = entropy + log_prior.mean()
    entropy_plus_prior += 0.5*torch.log(2*math.pi*math.e*import_mean_var)
    entropy_plus_prior += np.log(1./10) - 0.1*imports_mean.mean()
    elbo_surrogate_gradient = (log_prob_infections * (log_lik-log_lik.mean().detach())).mean() + entropy_plus_prior 
    elbo = log_lik.mean() + entropy_plus_prior
    potential = -(torch.logsumexp(log_lik, 0) - torch.log(torch.tensor(log_lik.shape[0]).float()) + log_prior.mean())
    
    return elbo, elbo_surrogate_gradient, log_lik.mean(), log_prior.mean(), potential, entropy

#
def gaussian_log_likelihood(x, mean, logdet, cov_inv):
    x = x.unsqueeze(-1)
    mean = mean.expand(x.shape[0], *mean.shape).unsqueeze(-1)
    cov_inv = cov_inv.expand(x.shape[0], *cov_inv.shape)
    loglik = -1/2 * logdet - 1./2 * (x - mean).transpose(1,2) @ cov_inv @ (x - mean)  - x.shape[1]/2 * np.log(2*np.pi)
    return loglik.squeeze(1).squeeze(1)