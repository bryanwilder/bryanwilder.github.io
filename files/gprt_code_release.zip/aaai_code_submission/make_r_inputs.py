import numpy as np
import pickle
test_frequency = 1

design = 'uniform_piecewise'

seroconversion_pdf =  np.loadtxt('sero_conversion_pdf.txt')
pcr_conversion_pdf = np.loadtxt('pcr_conversion_pdf.txt')
pcr_reversion_pdf = np.loadtxt('pcr_reversion_pdf.txt')
infectiousness_per_day = np.loadtxt('infectiousness_per_day.txt')
anamnestic_pdf = np.loadtxt('anamnestic_pdf.txt')


for test_type in ['pcr', 'sero']:

#    for frac_tested in [0.005, 0.01, 0.02, 0.05]:
    if 'xsection' in design:
        all_fracs =  [0.0005, 0.001, 0.002, 0.005]
    elif 'uniform' in design:
        all_fracs = [0.01, 0.02, 0.05, 0.1, 0.2]
    else:
        all_fracs = [0.005, 0.01, 0.02, 0.05]
    for frac_tested in all_fracs:
            for idx in range(100):
                instance =  pickle.load(open('inference_instance_{}_{}_{}_{}_{}.pkl'.format(design, test_type, test_frequency, frac_tested, idx), 'rb'))
                postests_per_day = instance[0]
                np.savetxt('postests_{}_{}_{}_{}_{}.csv'.format(design, test_type, test_frequency, frac_tested, idx), postests_per_day, delimiter=',')
                