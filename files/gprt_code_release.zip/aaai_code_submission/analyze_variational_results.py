import pickle
import numpy as np
import pandas as pd
import torch
import matplotlib.pyplot as plt

seroconversion_pdf =  np.loadtxt('sero_conversion_pdf.txt')
pcr_conversion_pdf = np.loadtxt('pcr_conversion_pdf.txt')
pcr_reversion_pdf = np.loadtxt('pcr_reversion_pdf.txt')
infectiousness_per_day = np.loadtxt('infectiousness_per_day.txt')
anamnestic_pdf = np.loadtxt('anamnestic_pdf.txt')

test_frequency = 7
design = 'imports'
mses_wt = {}
mses_cori = {}
mses_var = {}
mses_epinow = {}
cal = {}
cal_wt = {}
cal_cori = {}
cal_epinow = {}
delay_distr = 1./6 * np.ones(6)

for test_type in ['pcr', 'sero']:

    if test_type == 'pcr':
        delay_vals = []
        for _ in range(10000):
            convert_time = np.random.choice(pcr_conversion_pdf.shape[0], p = pcr_conversion_pdf)
            if 'uniform' in design:
                delay_vals.append(convert_time + np.random.choice(np.arange(len(delay_distr)), p=delay_distr))
            else:
                revert_time = np.random.choice(pcr_reversion_pdf[convert_time].shape[0], p = pcr_reversion_pdf[convert_time])
                next_test = np.random.randint(0, test_frequency)
                while next_test < convert_time:
                    next_test += test_frequency
                if next_test < revert_time:
                    delay_vals.append(next_test)
    else:
        delay_vals = []
        for _ in range(10000):
            convert_time = np.random.choice(seroconversion_pdf.shape[0], p = seroconversion_pdf)
            if 'uniform' in design:
                delay_vals.append(convert_time + np.random.choice(np.arange(len(delay_distr)), p=delay_distr))
            else:
                next_test = np.random.randint(0, test_frequency)
                while next_test < convert_time:
                    next_test += test_frequency
                delay_vals.append(next_test)
        
    mean_delay = int(np.round(np.mean(delay_vals)))
    print(mean_delay)
    
    if 'xsection' in design:
        all_fracs =  [0.0005, 0.001, 0.002, 0.005]
    elif 'uniform' in design:
        all_fracs = [0.01, 0.02, 0.05, 0.1]
    else:
        all_fracs = [0.005, 0.01, 0.02, 0.05]

    for frac_tested in all_fracs:
            mses_wt[(test_type, frac_tested)] = np.zeros(100)
            mses_cori[(test_type, frac_tested)]  = np.zeros(100)
            mses_var[(test_type, frac_tested)]  = np.zeros(100)
            mses_epinow[(test_type, frac_tested)]  = np.zeros(100)
            cal_wt[(test_type, frac_tested)] = {}
            cal_cori[(test_type, frac_tested)] = {}
            cal_epinow[(test_type, frac_tested)] = {}
            cal[(test_type, frac_tested)] = {}
#            alphas = [0.1, 0.25, 0.35, 0.5, 0.65, 0.75, 0.9]
            alphas = [0.05, 0.1, 0.2, 0.35, 0.5, 0.65, 0.8, 0.9, 0.95]
            T = 100
            for alpha in alphas:
                cal[(test_type, frac_tested)][alpha] = np.zeros((100, T))
                cal_wt[(test_type, frac_tested)][alpha] = []
                cal_cori[(test_type, frac_tested)][alpha] = []
                cal_epinow[(test_type, frac_tested)][alpha] = []
            results_epinow = np.load('../../New folder1/results_epinow_{}_{}_{}_{}.results.npy'.format(design, test_type, test_frequency, frac_tested))
            results_epinow[results_epinow > 2] = 2
                
            for idx in range(100):
                instance =  pickle.load(open('inference_instance_{}_{}_{}_{}_{}.pkl'.format(design, test_type, test_frequency, frac_tested, idx), 'rb'))
                r_time_all = instance[1].flatten()
                
                try:
                    results_wt = pd.read_csv('results_wt_{}_{}_{}_{}_{}.results'.format(design, test_type, test_frequency, frac_tested, idx))
                except:
                    print('no wt', idx)
                    continue
                results_cori = pd.read_csv('results_cori_{}_{}_{}_{}_{}.results'.format(design, test_type, test_frequency, frac_tested, idx))
                
                times_wt = results_wt['t_end'].to_numpy() - 1 - mean_delay
                times_wt = times_wt[times_wt >= 0]
                mses_wt[(test_type, frac_tested)][idx] = (np.abs(r_time_all[times_wt] - results_wt['Mean(R)'][results_wt['t_end'] - 1 >= mean_delay].to_numpy())).mean()

                times_cori = results_cori['t_end'].to_numpy() - 1 - mean_delay
                times_cori = times_cori[times_cori >= 0]
                mses_cori[(test_type, frac_tested)][idx] = (np.abs(r_time_all[times_cori] - results_cori['Mean(R)'][results_cori['t_end'] - 1 >= mean_delay].to_numpy())).mean()


                start_time = np.where(results_epinow[idx,0] != 0)[0][0]
                mses_epinow[(test_type, frac_tested)][idx] = np.median(np.abs(r_time_all[start_time:] - results_epinow[idx, :, start_time:].mean(axis=0)))
                
                results_var = pickle.load(open('../../variational_results/results_{}_{}_{}_{}_{}.pickle'.format(design, test_type, test_frequency, frac_tested, idx), 'rb'))
                mu = results_var[0]
                L = results_var[1]
                mses_var[(test_type, frac_tested)][idx] = (np.abs(mu.detach().numpy() - r_time_all)).mean()
                
                batch_size = 1000
                r = torch.relu(mu.expand(batch_size, mu.shape[1]) + (L.expand(batch_size, *L.shape) @ torch.randn(batch_size, L.shape[1], 1)).squeeze(2))
                def ci(a, alpha):
                    a = a.copy()
                    a.sort()
                    return a[int((alpha/2)*a.shape[0])], a[int((1-(alpha/2))*a.shape[0])]
                r = r.detach().numpy()
                for alpha_idx, alpha in enumerate(alphas):
                    cis = [ci(r[:, t], alpha) for t in range(r_time_all.shape[0])]
                    cis_lower = np.array([x[0] for x in cis])
                    cis_upper = np.array([x[1] for x in cis])
                    cal[(test_type, frac_tested)][alpha][idx] = (r_time_all >= cis_lower)*(r_time_all <= cis_upper)
                
                for alpha_idx, alpha in enumerate(alphas):
                    currslice = results_epinow[idx, :, start_time:]
                    cis = [ci(currslice[:, t], alpha) for t in range(currslice.shape[1])]
                    cis_lower = np.array([x[0] for x in cis])
                    cis_upper = np.array([x[1] for x in cis])
                    cal_epinow[(test_type, frac_tested)][alpha].extend((r_time_all[start_time:] >= cis_lower)*(r_time_all[start_time:] <= cis_upper))

                    
                for alpha_idx, alpha in enumerate(alphas):
                    cis_lower = results_wt['Quantile.{}(R)'.format(alpha/2)][results_wt['t_end'] - 1 >= mean_delay].to_numpy()
                    cis_upper = results_wt['Quantile.{}(R)'.format(1 - alpha/2)][results_wt['t_end'] - 1 >= mean_delay].to_numpy()
                    cal_wt[(test_type, frac_tested)][alpha].extend((r_time_all[times_wt] >= cis_lower)*(r_time_all[times_wt] <= cis_upper))
                
                
                mean = results_cori['Mean(R)'][results_cori['t_end'] - 1 >= mean_delay].to_numpy()
                std = results_cori['Std(R)'][results_cori['t_end'] - 1 >= mean_delay].to_numpy()
                var = std**2
                k = mean**2/var
                theta = var/mean
                r = np.zeros((1000, mean.shape[0]))
                for t in range(mean.shape[0]):
                    r[:, t] = np.random.gamma(k[t], theta[t], 1000)

                for alpha_idx, alpha in enumerate(alphas):
                    cis = [ci(r[:, t], alpha) for t in range(r.shape[1])]
                    cis_lower = np.array([x[0] for x in cis])
                    cis_upper = np.array([x[1] for x in cis])
                    cal_cori[(test_type, frac_tested)][alpha].extend((r_time_all[times_cori] >= cis_lower)*(r_time_all[times_cori] <= cis_upper))

            
            
names = ['WT', 'Cori', 'EpiNow', 'GPRt']
for i, res in enumerate([mses_wt, mses_cori, mses_epinow, mses_var]):
    to_print = names[i]
    for test_type in ['pcr', 'sero']:
#        for frac_tested in [0.005, 0.01, 0.02, 0.05]:
        for frac_tested in all_fracs:
            to_print += '&' 
            if i == 3:
                to_print += '\\textbf{'
            to_print += '{:.3} $\pm$ {:.3}'.format(res[(test_type, frac_tested)][np.isfinite(res[(test_type, frac_tested)])].mean(), res[(test_type, frac_tested)][np.isfinite(res[(test_type, frac_tested)])].std())
            if i == 3:
                to_print += '}'

        if test_type == 'pcr':
            to_print += '&'
    to_print += '\\\\'
    print(to_print)

import matplotlib as mpl
mpl.rcParams['ps.useafm'] = True
mpl.rcParams['pdf.use14corefonts'] = True
mpl.rcParams['text.usetex'] = True
mpl.rcParams['text.latex.preamble'] = [r'\usepackage{amsmath}']

fig, ax = plt.subplots(2, len(all_fracs), figsize=(12, 4), sharex=True, sharey=True)
for row_idx, test_type in enumerate(['pcr', 'sero']):
    for col_idx, frac_tested in enumerate(all_fracs):
        art1 = ax[row_idx, col_idx].scatter(1-  np.array(alphas),  np.array([np.mean(cal_wt[(test_type, frac_tested)][alpha]) for alpha in alphas]), marker = '^', color='C1')
        art2 =ax[row_idx, col_idx].scatter(1-  np.array(alphas), np.array([np.mean(cal_cori[(test_type, frac_tested)][alpha])for alpha in alphas]), facecolors='none', edgecolors='C4', linewidths=2)
        art3 = ax[row_idx, col_idx].scatter(1-  np.array(alphas), np.array([cal[(test_type, frac_tested)][alpha].flatten().mean() for alpha in alphas]), marker='x', color='C0')
        art4 =ax[row_idx, col_idx].scatter(1-  np.array(alphas), np.array([np.mean(cal_epinow[(test_type, frac_tested)][alpha])for alpha in alphas]), color='goldenrod', marker='s')

        legend_art = [art1, art2, art4, art3]
        ax[row_idx, col_idx].plot([0, 1], [0, 1], c='k', ls = '--')
        ax[row_idx, col_idx].tick_params(axis='both', which='major', labelsize=20)
        if col_idx == 0:
            ax[row_idx, col_idx].set_ylabel('Coverage', fontsize=25)
        if row_idx == 1:
            ax[row_idx, col_idx].set_xlabel('Posterior CI', fontsize=25)
        if row_idx == 0:
            ax[row_idx, col_idx].text(0.19, 0.85, '{}\%'.format(100*frac_tested), horizontalalignment='center', verticalalignment='center', transform=ax[row_idx, col_idx].transAxes,  fontsize=22)

ax[1, 3].legend(legend_art, ['WT', 'Cori', 'EpiNow', 'GPRt'], bbox_to_anchor=(1., -0.5), fontsize=25, ncol=4)
fig.savefig('calibration_plot_{}.pdf'.format(design), bbox_inches='tight')
