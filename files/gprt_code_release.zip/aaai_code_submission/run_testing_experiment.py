import numpy as np
import torch
from functools import partial
import pickle
import argparse
from testing_variational import simulate_wrapper, gaussian_log_likelihood, likelihood, elbo, likelihood_crosssection, likelihood_uniform

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='HMC and variational inference for outbreak detection')
    
    parser.add_argument('--nthreads', type=int, help='number of parallel threads to use', default=6)
    parser.add_argument('--frac_tested', type=float, help='fraction of population to sample', default=0.01)
    parser.add_argument('--test_frequency', type=int, help='for longitudinal setting, frequency of testing', default=14)
    parser.add_argument('--test_type', type=str, help='either pcr or serological', default='pcr')
    parser.add_argument('--idx', type=int, help='which saved instance to load and run', default=0)
    parser.add_argument('--lr', type=float, help='learning rate', default=1e-3)
    parser.add_argument('--batch', type=int, help='batch size', default=800)
    parser.add_argument('--niter', type=int, help='number of iterations to run for', default=7000)
    parser.add_argument('--expdir', type=str, help='directory to save results', default='')
    parser.add_argument('--design', type=str, help='combination of observation model and model generating ground truth Rt', default='imports')
    parser.add_argument('--p_tested', type=float, help='probability individual is tested in uniform underreporting', default=0.1)
    parser.add_argument('--resume', action='store_true', help='whether to load saved intermediate results for this instance and continue', default=False)

    args = parser.parse_args()

    np.random.seed(0)
    torch.random.manual_seed(0)
    
    print('starting')
    seroconversion_pdf =  np.loadtxt('sero_conversion_pdf.txt')
    pcr_conversion_pdf = np.loadtxt('pcr_conversion_pdf.txt')
    pcr_reversion_pdf = np.loadtxt('pcr_reversion_pdf.txt')
    infectiousness_per_day = np.loadtxt('infectiousness_per_day.txt')
    anamnestic_pdf = np.loadtxt('anamnestic_pdf.txt')
    import_mean = 5
    prev_infected_frac = 0.0
    num_init_infected = 5
    n = int(1e5)
    T = 100
    frac_tested = args.frac_tested
    test_frequency = args.test_frequency
    num_tested_per_day = int(n*frac_tested/test_frequency)
    num_samples = 1
    burn_in = 40
    
    delay_distr = 1./6 * np.ones(6)
    
    num_threads = args.nthreads
    
    test_type = args.test_type
    expdir = args.expdir
    design = args.design
    idx = args.idx
    p_tested = args.p_tested
    
    instance =  pickle.load(open('inference_instance_{}_{}_{}_{}_{}.pkl'.format(design, test_type, test_frequency, frac_tested, idx), 'rb'))
    postests_per_day = instance[0]
    lr = args.lr
    
    simulate_function = partial(simulate_wrapper, n=n, T=T, prev_infected_frac=prev_infected_frac, pcr_conversion_pdf=pcr_conversion_pdf, pcr_reversion_pdf=pcr_reversion_pdf, seroconversion_pdf=seroconversion_pdf, anamnestic_pdf=anamnestic_pdf, num_init_infected=num_init_infected, infectiousness_per_day=infectiousness_per_day, burn_in=burn_in)
    from sklearn.gaussian_process.kernels import Matern
    kernel = Matern(length_scale=20.0, nu=1.5)
    prior_cov = kernel(np.arange(T).reshape((T, 1))) + np.eye(T)*0.0001
    prior_mean = torch.tensor(2.0*np.ones(T)).float()
    prior_cov_inv = torch.tensor(np.linalg.inv(prior_cov)).float()
    prior_cov = torch.tensor(prior_cov).float()
    prior_logdet = torch.tensor(np.linalg.slogdet(prior_cov)[1]).float()

    prior_density_function = partial(gaussian_log_likelihood, mean=prior_mean, logdet=prior_logdet, cov_inv=prior_cov_inv)
    if 'xsection' in design:
        likelihood_function = partial(likelihood_crosssection, postests_per_day=postests_per_day, test_frequency=test_frequency, num_tested_per_day=num_tested_per_day, n=n, num_samples=num_samples)
    elif 'uniform' in design:
        likelihood_function = partial(likelihood_uniform, postests_per_day=postests_per_day, p_tested=p_tested, delay_distr=delay_distr, n=n, num_samples=num_samples)
    else:
        likelihood_function = partial(likelihood, postests_per_day=postests_per_day, test_frequency=test_frequency, num_tested_per_day=num_tested_per_day, n=n, num_samples=num_samples)
    
    r_max = 2.5
    batch_size = args.batch
    
    elbo_history = []
    
    mu = torch.tensor(1*np.ones((1, T)), requires_grad=True, dtype=torch.float)
    L = torch.tensor(0.1*np.linalg.cholesky(prior_cov.numpy()), requires_grad=True, dtype=torch.float)
    import_mean = torch.tensor(10, requires_grad = True, dtype=torch.float)
    import_mean_var = torch.tensor(0.5, requires_grad=True, dtype=torch.float)
    if args.resume:
        print('resuming')
        mu, L, elbo_history, import_mean, import_mean_var = pickle.load(open(expdir + 'results_{}_{}_{}_{}_{}.pickle'.format(design, test_type, test_frequency, frac_tested, idx), 'rb'))

    optim = torch.optim.Adam([mu, L, import_mean, import_mean_var], lr=lr)
    niter = args.niter
    for i in range(niter):
        elbo_val, elbo_grad, lik, prior, potential, entropy = elbo(mu, L, batch_size, num_threads, simulate_function, likelihood_function, prior_density_function, r_max, test_type, import_mean, import_mean_var)
        print(i, elbo_val.item(), mu.mean().item(), import_mean.item(), import_mean_var.item())
        elbo_history.append(elbo_val.item())
        loss = -elbo_grad
        optim.zero_grad()
        loss.backward()
        optim.step()
        L.data = L.tril()
        mu.data = torch.relu(mu)
        import_mean.data = torch.relu(import_mean)
        import_mean_var.data = torch.relu(import_mean_var)
        
        if i % 100 == 0:
            pickle.dump((mu, L, elbo_history, import_mean, import_mean_var), open(expdir + 'results_{}_{}_{}_{}_{}.pickle'.format(design, test_type, test_frequency, frac_tested, idx), 'wb'))
        
