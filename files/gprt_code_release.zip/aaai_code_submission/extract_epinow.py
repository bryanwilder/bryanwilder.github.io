import pandas as pd
import numpy as np
from datetime import datetime 
import os

expdir = 'INSERT'

for test_type in ['sero']:
#    for design in ['imports_piecewise', 'imports', 'xsection', 'xsection_piecewise', 'uniform', 'uniform_piecewise']:
    for design in ['imports_piecewise', 'imports']:
        if 'imports' in design:
#            freqvals = [14]
            freqvals = [7, 14]
        else:
            freqvals = [1]
        for test_frequency in freqvals:
            if 'xsection' in design:
                all_fracs =  [0.0005, 0.001, 0.002, 0.005]
            elif 'uniform' in design:
                all_fracs = [0.01, 0.02, 0.05, 0.1, 0.2]
            else:
                all_fracs = [0.005, 0.01, 0.02, 0.05]
            for frac_tested in all_fracs:
                samples = np.zeros((100, 1000, 100))
                print(design, test_type, test_frequency, frac_tested)
                savedir = 'results_epinow_{}_{}_{}_{}.results.npy'.format(design, test_type, test_frequency, frac_tested)
                if os.path.isfile(savedir):
                    continue
                for idx in range(100):
                    
                    path = '{}/results_epinow_{}_{}_{}_{}_{}.results'.format(expdir, design, test_type, test_frequency, frac_tested, idx)
                    try:
                        a = pd.read_csv(path)
                    except:
                        print('results_epinow_{}_{}_{}_{}_{}.results'.format(design, test_type, test_frequency, frac_tested, idx))
                        continue
                    a = a[a.variable == 'R']
                    a = a.reset_index()
                    d0 = datetime.strptime(a.date[0], '%Y-%m-%d %H:%M:%S').date()
                    t0 = (d0 - datetime(2020,1,1).date()).days

                    tmax = int(a.time.max())
                    for t in range(tmax):
                        samples[idx, :a[a.time == t+1].value.shape[0], t+t0] = a[a.time == t+1].value
                    if a[a.time == t+1].value.shape[0] != 1000:
                        print('results_epinow_{}_{}_{}_{}_{}.results'.format(design, test_type, test_frequency, frac_tested, idx), a[a.time == t+1].value.shape[0])
                
                np.save('results_epinow_{}_{}_{}_{}.results'.format(design, test_type, test_frequency, frac_tested), samples)